# AUTOMAIL AI — 7-Day Demo

AUTOMAIL AI is a self-hosted AI email assistant demo for founders. It runs on your machine, stores its configuration in a local SQLite file, and gives you a live view of how the NovaByte Solutions support brain classifies, prioritizes, and replies to email.

## Start in under a minute

```bash
npm install
npm start
```

Open [http://localhost:3000](http://localhost:3000), complete the three-step setup, and send a test email to the connected mailbox.

## What is included

- AI provider setup for OpenAI, Anthropic, or Gemini-compatible keys
- IMAP polling for new messages
- SMTP delivery of delayed AI replies
- SQLite persistence in `server/data/automail.sqlite`
- Seven-day session expiry
- Dashboard, inbox trace, chat assistant, settings, and sandbox company context
- Pre-trained NovaByte Solutions knowledge and communication rules

Credentials are stored locally in the SQLite database on the computer running this demo. Delete `server/data/automail.sqlite` to reset the demo completely.

See `SETUP-GUIDE.md` for mailbox-specific notes and test prompts.