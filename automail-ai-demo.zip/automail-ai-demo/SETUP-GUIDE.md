# AUTOMAIL AI Setup Guide

## 1. Install and launch

Use Node.js 18 or newer:

```bash
npm install
npm start
```

Then open `http://localhost:3000`.

## 2. Choose an AI provider

Select OpenAI, Anthropic, or Gemini and enter a key with access to a chat-capable model. The key is kept in the local SQLite database and is never sent to AUTOMAIL AI.

## 3. Connect a mailbox

For a custom mailbox, enter the provider's IMAP and SMTP hostnames and ports. Common secure defaults are IMAP `993` and SMTP `587` (STARTTLS) or `465` (TLS). Use a dedicated test mailbox when possible.

Gmail and Outlook usually require an app password or provider-specific OAuth/app configuration before IMAP and SMTP will accept a connection.

## 4. Set reply timing

Start with a short delay while testing. A reply is first classified and drafted, then held for the configured delay before SMTP delivery. You can pause auto-replies from Settings at any time.

## 5. Suggested test messages

- “Hi, how much does the Growth plan cost?”
- “Your app crashed and I lost my work. I’m furious.”
- “I want to cancel. Too expensive for my small team.”
- “I need enterprise pricing for 200 users.”
- “I’ve been charged twice this month. Fix this immediately.”

## Reset

Stop the server and remove `server/data/automail.sqlite`. The next launch starts a fresh seven-day session.