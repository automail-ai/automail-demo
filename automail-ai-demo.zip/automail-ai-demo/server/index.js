const fs = require("node:fs");
const path = require("node:path");
const crypto = require("node:crypto");
const express = require("express");
const Database = require("better-sqlite3");
const nodemailer = require("nodemailer");
require("dotenv").config({ path: path.join(__dirname, "..", ".env") });

const app = express();
const PORT = Number(process.env.PORT || 3000);
const CLIENT_DIR = path.join(__dirname, "..", "client");
const DATA_DIR = path.join(__dirname, "data");
fs.mkdirSync(DATA_DIR, { recursive: true });
const db = new Database(path.join(DATA_DIR, "automail.sqlite"));
db.pragma("journal_mode = WAL");
db.exec(`
  CREATE TABLE IF NOT EXISTS settings (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    started_at TEXT,
    expires_at TEXT,
    provider TEXT,
    api_key TEXT,
    email_address TEXT,
    imap_host TEXT,
    imap_port INTEGER,
    smtp_host TEXT,
    smtp_port INTEGER,
    username TEXT,
    password TEXT,
    reply_delay_seconds INTEGER NOT NULL DEFAULT 120,
    business_hours_only INTEGER NOT NULL DEFAULT 0,
    auto_replies_paused INTEGER NOT NULL DEFAULT 0
  );
  CREATE TABLE IF NOT EXISTS emails (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    message_id TEXT UNIQUE NOT NULL,
    from_address TEXT NOT NULL,
    from_name TEXT NOT NULL DEFAULT '',
    to_address TEXT NOT NULL,
    subject TEXT NOT NULL,
    body_text TEXT NOT NULL,
    received_at TEXT NOT NULL,
    classification TEXT NOT NULL,
    confidence INTEGER NOT NULL,
    sentiment TEXT NOT NULL,
    urgency TEXT NOT NULL,
    ai_reply TEXT,
    reply_sent_at TEXT,
    was_flagged INTEGER NOT NULL DEFAULT 0,
    flag_reason TEXT,
    status TEXT NOT NULL DEFAULT 'pending',
    reply_time_seconds REAL
  );
  CREATE TABLE IF NOT EXISTS chat (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    role TEXT NOT NULL,
    content TEXT NOT NULL,
    created_at TEXT NOT NULL
  );
`);

const suggestions = [
  "Hi, how much does the Growth plan cost?",
  "Your app crashed and I lost my work. I'm furious.",
  "I want to cancel. Too expensive for my small team.",
  "Do you integrate with Salesforce?",
  "I need enterprise pricing for 200 users.",
  "I've been charged twice this month. Fix this immediately.",
  "Love the product! Any referral program?",
];

function getSettings() {
  return db.prepare("SELECT * FROM settings WHERE id = 1").get() || null;
}

function sessionPayload(settings = getSettings()) {
  const now = Date.now();
  const expiresAt = settings?.expires_at ? new Date(settings.expires_at).getTime() : 0;
  return {
    configured: Boolean(settings?.started_at),
    active: Boolean(settings?.started_at && expiresAt > now),
    expired: Boolean(settings?.started_at && expiresAt <= now),
    remainingSeconds: settings?.started_at ? Math.max(0, Math.floor((expiresAt - now) / 1000)) : 0,
    expiresAt: settings?.expires_at || null,
    provider: settings?.provider || null,
    emailAddress: settings?.email_address || null,
  };
}

function settingsPayload(settings = getSettings()) {
  return {
    replyDelaySeconds: settings?.reply_delay_seconds ?? 120,
    businessHoursOnly: Boolean(settings?.business_hours_only),
    autoRepliesPaused: Boolean(settings?.auto_replies_paused),
    emailAddress: settings?.email_address || null,
    provider: settings?.provider || null,
  };
}

function classify(subject, body) {
  const content = `${subject} ${body}`.toLowerCase();
  let classification = "GENERAL";
  if (/unsubscribe|newsletter|seo services|marketing blast|casino/.test(content)) classification = "SPAM";
  else if (/cancel|downgrade|leave|close my account/.test(content)) classification = "CANCEL";
  else if (/enterprise|200 users|bulk pricing|schedule a call|sales/.test(content)) classification = "SALES";
  else if (/charged|invoice|billing|payment|price|cost|refund|twice/.test(content)) classification = "BILLING";
  else if (/feature|integrat|roadmap|would love|add support/.test(content)) classification = "FEATURE_REQUEST";
  else if (/crash|bug|error|broken|how do|help|sync|gantt|login/.test(content)) classification = "SUPPORT";
  const angry = /furious|angry|unacceptable|lawsuit|lawyer|legal|sue/.test(content) || /!{2,}/.test(body);
  const negative = angry || /frustrat|disappointed|terrible|hate|bad/.test(content);
  const critical = /breach|hacked|stolen|legal|lawyer|lawsuit/.test(content);
  const highValue = classification === "SALES" && /enterprise|50\+|200 users|unlimited/.test(content);
  const wasFlagged = critical || angry || highValue || (classification === "BILLING" && /twice|refund over|over \$200/.test(content));
  return {
    classification,
    sentiment: angry ? "angry" : negative ? "negative" : /love|thank|great/.test(content) ? "positive" : "neutral",
    urgency: critical ? "critical" : wasFlagged ? "high" : negative ? "medium" : "low",
    confidence: classification === "GENERAL" ? 72 : 94,
    wasFlagged,
    flagReason: critical ? "Security or legal concern" : angry ? "Angry tone needs human visibility" : highValue ? "High-value enterprise lead" : wasFlagged ? "Billing issue needs review" : null,
  };
}

function makeReply({ classification, fromName, fromAddress }) {
  const first = (fromName || fromAddress.split("@")[0] || "there").split(/\s+/)[0].replace(/[^a-zA-Z'-]/g, "") || "there";
  const copy = {
    BILLING: "Thanks for flagging this. Our Growth plan is $49/month, Business is $99/month, and annual billing includes 25% off. We can also look into duplicate charges or a refund under our 30-day money-back policy; please share the invoice number so we can take the next step.",
    SUPPORT: "Thanks for letting us know — we know a workflow interruption is frustrating. We’re looking into the details and the fastest next step is to send us the affected workspace and a timestamp so the team can trace it. We’ll follow up within the response time for your plan.",
    COMPLAINT: "We hear you, and you’re right to expect a smoother experience. We’re sorry this caused friction and we’re reviewing what happened with the team now. Please reply with the workspace and any error details so we can make this right quickly.",
    SALES: "Thanks for reaching out — we’d love to learn more about your team. Enterprise starts at $249/month with unlimited users, SSO, a dedicated account manager, SLA, and custom integrations. Share your team size and timeline and we’ll connect you with Marcus and the team for a tailored conversation.",
    FEATURE_REQUEST: "Thanks for the thoughtful request. We don’t have that capability today, but we’ve added the idea to the feature request log so the team can consider it alongside customer demand. Tell us a little about your workflow and we’ll keep you posted when there’s movement.",
    CANCEL: "Thanks for being candid with us. Before we process anything, what’s the main reason you’re considering canceling — price, a missing feature, or something else? If price is the blocker, we can offer 30% off for three months, and if you still want to leave, we’ll make the process straightforward.",
    SPAM: "",
    GENERAL: "Thanks for reaching out — we’re glad to help. NovaByte brings boards, timelines, time tracking, team chat, and reporting together so your team can ship with less overhead. Reply with a little more detail about what you’re trying to do and we’ll point you in the right direction.",
  }[classification];
  return copy ? `Hi ${first},\n\n${copy}\n\n— NovaByte Team` : "";
}

async function providerReply(settings, email, localReply) {
  if (!settings?.api_key) return localReply;
  const prompt = `Reply as the NovaByte Solutions support team. Keep it to 3-6 sentences, acknowledge the sender first, use accurate company facts, give a clear next step, and sign off as — NovaByte Team. Sender: ${email.fromName || email.fromAddress}. Subject: ${email.subject}. Body: ${email.bodyText}`;
  try {
    const signal = AbortSignal.timeout(8000);
    if (settings.provider === "openai") {
      const response = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        signal,
        headers: { "content-type": "application/json", authorization: `Bearer ${settings.api_key}` },
        body: JSON.stringify({ model: "gpt-4o-mini", temperature: 0.2, messages: [{ role: "system", content: "You are the NovaByte Solutions support team. Never mention being an AI." }, { role: "user", content: prompt }] }),
      });
      if (response.ok) return (await response.json()).choices?.[0]?.message?.content?.trim() || localReply;
    } else if (settings.provider === "anthropic") {
      const response = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        signal,
        headers: { "content-type": "application/json", "x-api-key": settings.api_key, "anthropic-version": "2023-06-01" },
        body: JSON.stringify({ model: "claude-3-5-haiku-latest", max_tokens: 350, system: "You are the NovaByte Solutions support team. Never mention being an AI.", messages: [{ role: "user", content: prompt }] }),
      });
      if (response.ok) return (await response.json()).content?.[0]?.text?.trim() || localReply;
    } else if (settings.provider === "gemini") {
      const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${encodeURIComponent(settings.api_key)}`, {
        method: "POST",
        signal,
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ contents: [{ parts: [{ text: `${prompt}\n\nNever mention being an AI.` }] }] }),
      });
      if (response.ok) return (await response.json()).candidates?.[0]?.content?.parts?.[0]?.text?.trim() || localReply;
    }
    console.error("[AUTOMAIL] AI provider returned a non-success response; using sandbox reply");
  } catch (error) {
    console.error("[AUTOMAIL] AI provider request failed; using sandbox reply:", error.message);
  }
  return localReply;
}

function mapEmail(email) {
  return {
    id: email.id,
    fromAddress: email.from_address,
    fromName: email.from_name,
    toAddress: email.to_address,
    subject: email.subject,
    bodyText: email.body_text,
    receivedAt: email.received_at,
    classification: email.classification,
    confidence: email.confidence,
    sentiment: email.sentiment,
    urgency: email.urgency,
    aiReply: email.ai_reply,
    replySentAt: email.reply_sent_at,
    wasFlagged: Boolean(email.was_flagged),
    flagReason: email.flag_reason,
    status: email.status,
    replyTimeSeconds: email.reply_time_seconds,
  };
}

function sendSmtpReply(email, settings) {
  if (!settings?.smtp_host || !settings?.username || !settings?.password || !email.ai_reply) return;
  const transport = nodemailer.createTransport({
    host: settings.smtp_host,
    port: settings.smtp_port || 587,
    secure: Number(settings.smtp_port) === 465,
    auth: { user: settings.username, pass: settings.password },
  });
  transport.sendMail({
    from: settings.email_address,
    to: email.from_address,
    subject: `Re: ${email.subject}`,
    text: email.ai_reply,
  }).catch((error) => console.error("[AUTOMAIL] SMTP send failed:", error.message));
}

function queueReply(emailId, delaySeconds) {
  const seconds = Math.max(0, Math.min(Number(delaySeconds || 120), 86400));
  setTimeout(() => {
    const email = db.prepare("SELECT * FROM emails WHERE id = ?").get(emailId);
    const settings = getSettings();
    if (!email || email.status === "archived" || settings?.auto_replies_paused) return;
    const sentAt = new Date().toISOString();
    const replyTime = Math.max(1, (Date.now() - new Date(email.received_at).getTime()) / 1000);
    db.prepare("UPDATE emails SET status = 'replied', reply_sent_at = ?, reply_time_seconds = ? WHERE id = ?").run(sentAt, replyTime, emailId);
    sendSmtpReply({ ...email, reply_sent_at: sentAt }, settings);
  }, seconds * 1000);
}

async function saveIncoming({ fromAddress, fromName = "", subject, bodyText, messageId = crypto.randomUUID() }) {
  const settings = getSettings();
  const analysis = classify(subject, bodyText);
  const status = analysis.classification === "SPAM" ? "archived" : analysis.wasFlagged ? "flagged" : "pending";
  const reply = await providerReply(settings, { fromName, fromAddress, subject, bodyText }, makeReply({ classification: analysis.classification, fromName, fromAddress }));
  const result = db.prepare(`
    INSERT INTO emails (message_id, from_address, from_name, to_address, subject, body_text, received_at, classification, confidence, sentiment, urgency, ai_reply, was_flagged, flag_reason, status)
    VALUES (@messageId, @fromAddress, @fromName, @toAddress, @subject, @bodyText, @receivedAt, @classification, @confidence, @sentiment, @urgency, @aiReply, @wasFlagged, @flagReason, @status)
  `).run({
    messageId, fromAddress, fromName, toAddress: settings?.email_address || "demo@automail.local", subject, bodyText,
    receivedAt: new Date().toISOString(), ...analysis, aiReply: reply || null, wasFlagged: analysis.wasFlagged ? 1 : 0, status,
  });
  if (status !== "archived") queueReply(result.lastInsertRowid, settings?.reply_delay_seconds || 120);
  return mapEmail(db.prepare("SELECT * FROM emails WHERE id = ?").get(result.lastInsertRowid));
}

function pollInbox() {
  const settings = getSettings();
  if (!settings?.imap_host || !settings?.username || !settings?.password || sessionPayload(settings).expired) return;
  import("imapflow").then(async ({ ImapFlow }) => {
    const client = new ImapFlow({ host: settings.imap_host, port: settings.imap_port || 993, secure: true, auth: { user: settings.username, pass: settings.password }, logger: false });
    try {
      await client.connect();
      const lock = await client.getMailboxLock("INBOX");
      try {
        for await (const message of client.fetch({ seen: false }, { envelope: true, source: true, uid: true })) {
          const messageId = message.envelope?.messageId || `imap-${message.uid}`;
          if (db.prepare("SELECT id FROM emails WHERE message_id = ?").get(messageId)) continue;
          const from = message.envelope?.from?.[0] || {};
          const raw = message.source?.toString() || "";
          const body = raw.split(/\r?\n\r?\n/).slice(1).join("\n\n").slice(0, 20000);
          await saveIncoming({ messageId, fromAddress: from.address || "unknown@example.com", fromName: from.name || "", subject: message.envelope?.subject || "(no subject)", bodyText: body });
          await client.messageFlagsAdd(message.uid, ["\\Seen"]);
        }
      } finally { lock.release(); }
      await client.logout();
    } catch (error) {
      console.error("[AUTOMAIL] IMAP poll failed:", error.message);
      try { await client.logout(); } catch {}
    }
  }).catch((error) => console.error("[AUTOMAIL] IMAP adapter unavailable:", error.message));
}

app.use(express.json({ limit: "1mb" }));
app.use((req, res, next) => { res.setHeader("Access-Control-Allow-Origin", "*"); next(); });

app.get("/api/session", (_req, res) => res.json(sessionPayload()));
app.post("/api/setup/validate-ai", (req, res) => {
  const { provider, apiKey } = req.body || {};
  const valid = typeof apiKey === "string" && apiKey.length > 12 && (provider !== "openai" || apiKey.startsWith("sk-"));
  res.json({ valid, message: valid ? "Provider key format verified. Your key stays on your machine." : "That key format doesn’t look right for the selected provider." });
});
app.post("/api/setup/validate-email", (req, res) => {
  const { emailAddress, imapHost, imapPort, smtpHost, smtpPort } = req.body || {};
  const valid = Boolean(emailAddress?.includes("@") && imapHost && smtpHost && Number(imapPort) > 0 && Number(smtpPort) > 0);
  res.json({ valid, message: valid ? "Connection details look ready. The demo will monitor this inbox after launch." : "Add a valid email address and IMAP/SMTP host details to continue." });
});
app.post("/api/setup/launch", (req, res) => {
  const body = req.body || {};
  const startedAt = new Date();
  const expiresAt = new Date(startedAt.getTime() + Number(process.env.DEMO_DURATION_DAYS || 7) * 86400000);
  db.prepare(`
    INSERT INTO settings (id, started_at, expires_at, provider, api_key, email_address, imap_host, imap_port, smtp_host, smtp_port, username, password, reply_delay_seconds, business_hours_only, auto_replies_paused)
    VALUES (1, @startedAt, @expiresAt, @provider, @apiKey, @emailAddress, @imapHost, @imapPort, @smtpHost, @smtpPort, @username, @password, @replyDelaySeconds, @businessHoursOnly, 0)
    ON CONFLICT(id) DO UPDATE SET started_at=@startedAt, expires_at=@expiresAt, provider=@provider, api_key=@apiKey, email_address=@emailAddress, imap_host=@imapHost, imap_port=@imapPort, smtp_host=@smtpHost, smtp_port=@smtpPort, username=@username, password=@password, reply_delay_seconds=@replyDelaySeconds, business_hours_only=@businessHoursOnly, auto_replies_paused=0
  `).run({
    startedAt: startedAt.toISOString(), expiresAt: expiresAt.toISOString(), provider: body.provider, apiKey: body.apiKey,
    emailAddress: body.emailAddress, imapHost: body.imapHost || null, imapPort: body.imapPort || null,
    smtpHost: body.smtpHost || null, smtpPort: body.smtpPort || null, username: body.username || body.emailAddress,
    password: body.password || null, replyDelaySeconds: Number(body.replyDelaySeconds || 120), businessHoursOnly: body.businessHoursOnly ? 1 : 0,
  });
  pollInbox();
  res.json(sessionPayload());
});

function dashboardData() {
  const rows = db.prepare("SELECT * FROM emails ORDER BY datetime(received_at) DESC LIMIT 100").all();
  const timed = rows.filter((row) => row.reply_time_seconds !== null);
  return {
    stats: { received: rows.length, replied: rows.filter((row) => row.status === "replied").length, flagged: rows.filter((row) => row.was_flagged).length, avgReplySeconds: timed.length ? timed.reduce((sum, row) => sum + row.reply_time_seconds, 0) / timed.length : null },
    recentActivity: rows.slice(0, 6).map(mapEmail),
    suggestions,
    settings: settingsPayload(),
  };
}
app.get("/api/dashboard", (_req, res) => res.json(dashboardData()));
app.get("/api/emails", (req, res) => {
  let rows = db.prepare("SELECT * FROM emails ORDER BY datetime(received_at) DESC LIMIT 100").all();
  if (req.query.category) rows = rows.filter((row) => row.classification === String(req.query.category).toUpperCase());
  if (req.query.status) rows = rows.filter((row) => row.status === req.query.status);
  res.json(rows.map(mapEmail));
});
app.get("/api/emails/:id", (req, res) => {
  const row = db.prepare("SELECT * FROM emails WHERE id = ?").get(Number(req.params.id));
  row ? res.json(mapEmail(row)) : res.status(404).json({ error: "Email not found" });
});
app.post("/api/demo/incoming", async (req, res) => res.status(201).json(await saveIncoming(req.body || {})));
app.post("/api/chat", (req, res) => {
  const message = String(req.body?.message || "");
  const rows = db.prepare("SELECT * FROM emails ORDER BY datetime(received_at) DESC LIMIT 100").all();
  const lower = message.toLowerCase();
  const flagged = rows.filter((row) => row.was_flagged);
  const complaints = rows.filter((row) => row.classification === "COMPLAINT");
  let content = `You’ve handled ${rows.length} email${rows.length === 1 ? "" : "s"} in this demo, with ${rows.filter((row) => row.status === "replied").length} auto-replied and ${flagged.length} flagged for review.`;
  if (lower.includes("complaint")) content = complaints.length ? `I found ${complaints.length} complaint${complaints.length === 1 ? "" : "s"}. The latest is “${complaints[0].subject}” and it’s ${complaints[0].status}.` : "There aren’t any complaints in the inbox yet.";
  if (lower.includes("common") || lower.includes("category")) content = rows.length ? `${rows[0].classification} is the latest category in the inbox. Ask me for stats or flagged messages for a deeper view.` : "There isn’t enough email activity yet to identify a common question.";
  db.prepare("INSERT INTO chat (role, content, created_at) VALUES (?, ?, ?)").run("user", message, new Date().toISOString());
  db.prepare("INSERT INTO chat (role, content, created_at) VALUES (?, ?, ?)").run("assistant", content, new Date().toISOString());
  res.json({ role: "assistant", content, createdAt: new Date().toISOString() });
});
app.get("/api/settings", (_req, res) => res.json(settingsPayload()));
app.put("/api/settings", (req, res) => {
  const body = req.body || {};
  db.prepare("UPDATE settings SET reply_delay_seconds = COALESCE(?, reply_delay_seconds), business_hours_only = COALESCE(?, business_hours_only) WHERE id = 1").run(body.replyDelaySeconds ?? null, body.businessHoursOnly === undefined ? null : body.businessHoursOnly ? 1 : 0);
  res.json(settingsPayload());
});
app.post("/api/settings/pause", (_req, res) => { db.prepare("UPDATE settings SET auto_replies_paused = 1 WHERE id = 1").run(); res.json(settingsPayload()); });
app.post("/api/settings/resume", (_req, res) => { db.prepare("UPDATE settings SET auto_replies_paused = 0 WHERE id = 1").run(); res.json(settingsPayload()); });

app.use(express.static(CLIENT_DIR));
app.get("*", (_req, res) => res.sendFile(path.join(CLIENT_DIR, "index.html")));
app.listen(PORT, () => console.log(`AUTOMAIL AI running at http://localhost:${PORT}`));
setInterval(pollInbox, 30000);